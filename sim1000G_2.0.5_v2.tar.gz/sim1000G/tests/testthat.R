library(testthat)
library(sim1000G)

test_check("sim1000G")
