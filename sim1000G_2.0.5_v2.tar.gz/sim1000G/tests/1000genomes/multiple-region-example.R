

## This list of examples will download 2 gene VCFs from the github repository,
## and use it to create multiple example simulations with new features of sim1000G


#### Download gene list and gene vcf files from GitHUB repository ####

library(sim1000G)

readGeneList = function() {
    url = "https://raw.githubusercontent.com/adimitromanolakis/sim1000G-gene-regions/main/ensembl-genes-grch37.csv"
    genes = read.csv(url, as=T)
    genes = genes[ genes$Transcript.type == "protein_coding" , ]
    genes = genes[ genes$Chromosome.scaffold.name %in% as.character(1:22) , ]
    genes
}

if( ! exists("genes") )
    genes = readGeneList()



geneVCFGitHubLocation = function(gene) {

    s = genes[genes$Gene.name == gene,]
    chrom = s$Chromosome.scaffold.name[1]

    f = "https://raw.githubusercontent.com/adimitromanolakis/sim1000G-gene-regions/main/ceu-tsi-gbr/chr%s/genes-chr%s-%s.vcf.gz"
    f = sprintf(f,chrom,chrom,gene)

    cat("-> Gene location for download is",f, "\n")
    f
}


downloadGeneticMap(4, dir = "/tmp/")
downloadGeneticMap(6, dir = "/tmp/")

#### Example 1: Start a multiple region simulation ####


library(sim1000G)

readGeneticMap(4, dir = "/tmp")
readGeneticMap(6, dir = "/tmp")

vcf1 = readVCF(geneVCFGitHubLocation("CNR1"))
vcf2 = readVCF(geneVCFGitHubLocation("TMEM156"))


#startSimulation(vcf2, totalNumberOfIndividuals = 4444)
startMultipleRegionSimulation( list(vcf1, vcf2), region_names = c("a", "b"), totalNumberOfIndividuals = 5000 )

marker_info = markerInfo()
marker_info

ids <- generateUnrelatedIndividuals(400)


## Two ways to retrieve all the genotypes of individuals



g1 = retrieveGenotypes( ids )
str(g1)


# Retrieve a list of specific markers

g2 = retrieveGenotypes(ids, 1:20)
str(g2)


table( g1[, 1:20] == g2 )




#### Compute average IBD over two offspring ####


ids = generateUnrelatedIndividuals(10)

f = function(i) {
    child1 = mate(ids[1], ids[2])
    child2 = mate(ids[1], ids[2])
    return ( computePairIBD12(child1, child2, region="a") )
}



x = SIM$regions[[1]]$cm
SIM$regions[[1]]$cm = seq(0,2000,l = length(x) )

x = SIM$regions[[2]]$cm
SIM$regions[[2]]$cm = seq(0,2000,l = length(x) )



system.time (ibd <- lapply(1:2000,f) )
ibd = do.call(rbind,ibd)
str(ibd)

mean(ibd[,1])
mean(ibd[,2])





### Example 2: Compute pairwise IBD1,2: Different ways to retrieve the IBD information ####



resetSimulation()

ids = generateUnrelatedIndividuals(3)

k1 = mate(ids[1] , ids[2])
k2 = mate(ids[1] , ids[2])




# Retrieve mean IBD over the region
computePairIBD12(k1, k2)

# Retrieve IBD for each marker
computePairIBD12(k1, k2, allMarkers = TRUE)


# Retrieve IBD for a set of markers
computePairIBD12(k1, k2, markers = 1:20, allMarkers = TRUE)


#### Example 3: Compute IBD matrix ####


resetSimulation()

ids = generateUnrelatedIndividuals(3)

k1 = mate(ids[1] , ids[2])
k2 = mate(ids[1] , ids[2])


individual_list = c(ids, k1, k2)

M = computeIBDMatrix(individual_list, individual_list)
print(M)




# Verify the matrix is correct, by comparing it with values from computePairIBD12

A = individual_list
B = individual_list

M = computeIBDMatrix(A, B)

for(i in 1:length(A)) {

    for(j in 1:length(B)) {
        v = computePairIBD12(A[i], B[j])

        stopifnot( M$IBD1[i,j] == v[1] )
        stopifnot( M$IBD2[i,j] == v[2] )
    }
}












#### Example 4: Compute allele sharing coefficient from IBD ####


fam2 = newFamilyWithOffspring("family1", 3)
print(fam2)




individual1 = fam2$gtindex[3]
individual2 = fam2$gtindex[4]


# mean IBD1/2
computePairIBD12(individual1,individual2)


# True allele sharing by IBD

ibd = computePairIBD12(individual1, individual2, allMarkers = T)

ibd1 = ibd$IBD1
ibd2 = ibd$IBD2


alleles_shared = 2*ibd2 + ibd1

true_allele_sharing_coefficient = mean( alleles_shared/2 )

true_allele_sharing_coefficient




marker_info = markerInfo()
head(marker_info)


# Formula 6: Allele sharing coefficient from IBS (assuming IBD status is not known, as per formula 6) #


g = retrieveGenotypes(c(fam2$gtindex[3],fam2$gtindex[4]))

gt1 = g[1,]
gt2 = g[2,]


# Formula 6
m = length(gt1)
1/2 + sum( (gt1-1)*(gt2-1) ) / ( 2 * m )


# Formula 7


maf = marker_info$maf
range(maf)

(1/m) * sum( (gt1 - 2*maf) * ( gt2 - 2*maf) )





# Formula 9

maf = marker_info$maf

D = sqrt( 2 * maf * (1-maf) )
Xb = (gt1 - 2*maf) / D
Xc = (gt2 - 2*maf) / D

(1/m) * sum( Xb * Xc )







# For debugging IBD1,2 calculation, the following overrides the centiMorgan
#  locations of the markers.
#SIM$regions[[1]]$cm = seq(0,3000, l = SIM$regions[[1]]$N_markers )
#SIM$regions[[2]]$cm = seq(0,3000, l = SIM$regions[[2]]$N_markers )

