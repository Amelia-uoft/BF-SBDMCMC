

### IBD12Matrix = function(ids)

startSimulation(vcf2, totalNumberOfIndividuals = 4444)
startMultipleRegionSimulation(list(vcf1,vcf2), totalNumberOfIndividuals = 4444)


resetSimulation()
ids1 = generateUnrelatedIndividuals(5)
ids1
ids2 = sapply(1:10, function(i) mate(ids1[1], ids1[2]))

ids = 1:3

computeIBDMatrix(ids2,ids2, 1:50)

collectOrigin1 = function(ids1) {

    x = lapply(SIM$regions, function(S) { q = S$origin1[ids1]; do.call(rbind,q) } )
    do.call(cbind, x)

}


str(collectOrigin1(1:3))


q1 = SIM$origin1[ids]
q1 = do.call(rbind, q1)

q2 = SIM$origin2[ids]
q2 = do.call(rbind, q2)



ids2 = c(1,4,5,6)

r1 = SIM$origin1[ids2]
r1 = do.call(rbind, r1)

r2 = SIM$origin2[ids2]
r2 = do.call(rbind, r2)


## Result matrices


IBD1matrix = matrix(nrow = length(ids), ncol = length(ids2), NA )
IBD2matrix = matrix(nrow = length(ids), ncol = length(ids2), NA )





q1 = q1[,1:10]
q2 = q2[,1:10]
r1 = r1[,1:10]
r2 = r2[,1:10]

# first individual
x = q1[1,]
y = q2[1,]

x
y

#x = 1:length(x)

x[5] = 22
y[5] = -22

nind = nrow(r1)
nind

Q1 = matrix(x, byrow = T, nrow = nrow(r1), ncol = ncol(r1))
Q1

Q2 = matrix(y, byrow = T, nrow = nrow(r1), ncol = ncol(r1))
Q2


X == r1

IBD1H1 = Q1 == r1 | Q1 == r2
IBD1H2 = Q2 == r1 | Q2 == r2

IBD1H1
IBD1H2

IBD12 = IBD1H1 | IBD1H2
IBD2 =  (Q1 == r1 & Q2 == r2 )  | (Q1 == r2 & Q2 == r1)


IBD12
IBD2

meanIBD12 = rowMeans(IBD12)
meanIBD2 = rowMeans(IBD2)

IBD2matrix[1,] = meanIBD12 - meanIBD2
IBD1matrix[1,] = meanIBD2




#### Test matrix function ####


computeIBDMatrix = function(ids, ids2) {

    q1 = SIM$origin1[ids]
    q1 = do.call(rbind, q1)

    q2 = SIM$origin2[ids]
    q2 = do.call(rbind, q2)


    r1 = SIM$origin1[ids2]
    r1 = do.call(rbind, r1)

    r2 = SIM$origin2[ids2]
    r2 = do.call(rbind, r2)


    # Result matrices

    IBD1matrix = matrix(nrow = length(ids), ncol = length(ids2), NA )
    IBD2matrix = matrix(nrow = length(ids), ncol = length(ids2), NA )


    # Compute each row of the matrix separately

    for(i in 1:length(ids)) {

        x = q1[i,]
        y = q2[i,]

        nind = nrow(r1)

        Q1 = matrix(x, byrow = T, nrow = nrow(r1), ncol = ncol(r1))

        Q2 = matrix(y, byrow = T, nrow = nrow(r1), ncol = ncol(r1))

        IBD1H1 = Q1 == r1 | Q1 == r2
        IBD1H2 = Q2 == r1 | Q2 == r2

        IBD12 = IBD1H1 | IBD1H2
        IBD2 =  (Q1 == r1 & Q2 == r2 )  | (Q1 == r2 & Q2 == r1)

        meanIBD12 = rowMeans(IBD12)
        meanIBD2 = rowMeans(IBD2)

        IBD1matrix[i,] = meanIBD12 - meanIBD2
        IBD2matrix[i,] = meanIBD2

    }

    list(IBD1=IBD1matrix, IBD2=IBD2matrix)
}


A = ids2
B = ids2

M = computeIBDMatrix(A, B)

for(i in 1:length(A)) {

    for(j in 1:length(B)) {

        v = computePairIBD12(A[i],B[j])

        #cat("Ind ",i,j," : M=", M$IBD1[i,j], " diff = ", v[1] - M$IBD1[i,j], "\n")
        #cat("Ind ",i,j," : M=", M$IBD2[i,j], " diff = ", v[2] - M$IBD2[i,j], "\n")

        stopifnot( M$IBD1[i,j] == v[1] )
        stopifnot( M$IBD2[i,j] == v[2] )

    }
}






ped1 = newNuclearFamily(1)
computeIBDMatrix(ped1$gtindex, ped1$gtindex)



