a = read.table("/tmp/1",as=T,h=F)
a[1,]

a$POS = a$V2
x = a$V3
x = sub(".*DP=","",x)
x = sub(";.*$","",x)
a$DP = as.numeric(x)
x[1:5]


a$DP = caTools::runmean(a$DP,200)



plot(a$POS/1e6, a$DP,t="l",xlim=c(4,6),ylim=c(0,50e3))

genes[1,]
g = genes[genes$Chromosome.scaffold.name == "10",]
g[1,]
x1 = g$Transcript.start..bp./1e6
x2 = g$Transcript.end..bp./1e6
y1 = runif(length(x1), 0,5e3)

rect( x1,y1,x2,y1*1.2)

nrow(a)


## liftover file
# https://hgdownload.soe.ucsc.edu/gbdb/hg19/liftOver/

fname = downloadGeneticMap(2,"/tmp/")

map = read.table(fname,as=T,h=T)

d = data.frame(CHROM = map$Chromosome, POS = map$Position.bp.,
               POS2 = map$Position.bp.,
               ID = 1:nrow(map))

f = file("/tmp/out.bedgraph","w")
cat("track type=bedGraph\n", file=f)
write.table(d,col.names = F, row = F , quote=F,sep="\t" ,file=f)
close(f)

system(" cd /tmp/ && /home/apo/.local/bin/CrossMap.py bed hg19ToHg38.over.chain.gz out.bedgraph out2.bed")


b = read.table("/tmp/out2.bed", as=T)
str(b)
str(d)

d[1,]

d$NEW = NA
d$NEW[b$V4] = b$V3

d[ which(d$POS - d$NEW > 500e3) ,]
hist(d$POS-d$NEW,n=300)



plot(d$POS/1e6, (d$POS-d$NEW)/1e6,t="l",xlim=c(0,220),ylim=c(-1,1) )
