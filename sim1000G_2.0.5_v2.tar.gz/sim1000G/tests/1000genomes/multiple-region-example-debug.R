
#### Download gene list and gene vcf files from githib repository ####

library(sim1000G)

readGeneList = function() {
    url = "https://raw.githubusercontent.com/adimitromanolakis/sim1000G-gene-regions/main/ensembl-genes-grch37.csv"
    genes = read.csv(url, as=T)
    genes = genes[ genes$Transcript.type == "protein_coding" , ]
    genes = genes[ genes$Chromosome.scaffold.name %in% as.character(1:22) , ]
    genes
}

if( ! exists("genes") )
    genes = readGeneList()



geneVCFGitHubLocation = function(gene) {

    s = genes[genes$Gene.name == gene,]
    chrom = s$Chromosome.scaffold.name[1]

    f = "https://raw.githubusercontent.com/adimitromanolakis/sim1000G-gene-regions/main/ceu-tsi-gbr/chr%s/genes-chr%s-%s.vcf.gz"
    f = sprintf(f,chrom,chrom,gene)

    print(f)
    f
}


downloadGeneticMap(4, dir = "/tmp/")
downloadGeneticMap(6, dir = "/tmp/")

#### Example 1: Start a multiple region simulation ####


library(sim1000G)

readGeneticMap(4, dir = "/tmp")
readGeneticMap(6, dir = "/tmp")

vcf1 = readVCF(geneVCFGitHubLocation("CNR1"))
vcf2 = readVCF(geneVCFGitHubLocation("TMEM156"))


startMultipleRegionSimulation( list(vcf1, vcf2), region_names = c("a", "b"), totalNumberOfIndividuals = 3000 )

#str(list.len=35,as.list(SIM$regions[[1]]))


#markerInfo()

# bench 1 : before changes this took 6.4 with 3000 individuals elapsed

resetSimulation()

library(profvis)
profvis({

system.time( ids <- generateUnrelatedIndividuals(400) )

})


str(as.list(SIM$regions$a))



resetSimulation()

ids = generateUnrelatedIndividuals(20)






f = function(i) {
    child1 = mate(1,2)
    child2 = mate(1,2)
    return ( computePairIBD12(child1, child2, region="a") )
}


f2 = function(i) {
    child1 = mate(1,2)
    child2 = mate(1,2)

    cousin1 = mate(child1, ids[3])
    cousin2 = mate(child2, ids[4])

    computePairIBD12(cousin1, cousin2, region="a")
}


retrieveGenotypes(c(10,11))
retrieveGenotypes(c(10))


system.time (ibd <- lapply(1:400,f) )
ibd = do.call(rbind,ibd)
str(ibd)

mean(ibd[,1])
mean(ibd[,2])








### Example 2: Compute pairwise IBD1,2 for each markers ####

resetSimulation()

ids = generateUnrelatedIndividuals(20)

k1 = mate(ids[1] , ids[2])
k2 = mate(ids[1] , ids[2])

computePairIBD1(k2,k1)
computePairIBD2(k2,k1)
computePairIBD12(k2,k1, allMarkers = T)
computePairIBD12(k2,k1, allMarkers = F)

computePairIBD12(k2,k1, region="b", allMarkers = T)


computePairIBD12(k2,k1, region="b", markers = 1:10)




retrieveGenotypes(1, region="b")



markers = markerInfo()
str(markers)

markerInfo(region="a")



#### Example 3 ####

SIM$regions[[1]]$cm = seq(0,3000, l = SIM$regions[[1]]$N_markers )


fam2 = newFamilyWithOffspring("family1", 3)
print(fam2)

computePairIBD12(fam2$gtindex[5],fam2$gtindex[4])





## TODO:
## (OK) retrieve marker maf
## (OK) add region id to the output
## (OK) Compute IBD for selected genotypes for the region

