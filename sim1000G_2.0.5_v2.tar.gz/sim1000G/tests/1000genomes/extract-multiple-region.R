pkg.opts$debug_flag = 1
startMultipleRegionSimulation( list(vcf1, vcf2), region_names = c("a", "b"), totalNumberOfIndividuals = 3000 )
ids <- generateUnrelatedIndividuals(400)



marker_info = markerInfo()
marker_info



dim( SIM$regions[[1]]$gt1 )


SIM$regions[['a']]$gt1[,1:10]


marker_info

dim(marker_info)


i=1
for(i in 1:length(names_r)) {

    g1  = SIM$regions[[i]]$gt1
    m = length(g1)

    for(j in 1:m) {
        n = length(g1[[1]])
        g1[[j]] = sprintf("r%s i%d_m%d", i, j, 1:n)
    }

    SIM$regions[[i]]$gt1 = g1
}

(g1)[ 1:60, 1000]


x = c(3:5, 15, 59, 60 , 61 , 120:130)
r = marker_info$region_name[x]

i = 1

ids = 1:10
nind = length(ids)
nmark = length(x)


m = matrix(nrow = nmark, ncol = nind)
m

names_r = names(SIM$regions)


x2 = x

for(i in 1:length(names_r)) {

    region = names_r[[i]]

    index1 = which(r == region)

    # Index of markers to retrieve from gt1,gt2
    markers1 = x2[index1]

    x2 = x2 - SIM$regions[[region]]$N_markers

    cat("Extract region ", region, " : " , markers1, " x ", ids,"\n")

    gt1 = SIM$regions[[region]]$gt1[ markers1 , ids]
    gt2 = SIM$regions[[region]]$gt2[ markers1 , ids]

    m[ index1 , ] = as.matrix(gt1) # + as.matrix(gt2)

}








#### test ####



retrieveGenotypes_selection = function(SIM, ids, markers) {
    ids = as.numeric(ids)

    if(length(ids) == 1) {
        gt1 = as.matrix(SIM$gt1[markers, ids])
        gt2 = as.matrix(SIM$gt2[markers, ids])

        return(gt1 + gt2)
    }

    gt1 = as.matrix(SIM$gt1[markers, ids])
    gt2 = as.matrix(SIM$gt2[markers, ids])

    m = t(gt1 + gt2)

    rownames(m) = ids

    m
}



dim( retrieveGenotypes_selection(SIM$regions[[1]], 1:5, 300+1:10 ) )


dim( retrieveGenotypes_selection(SIM$regions[[1]], 300+1:10) )



retrieveGenotypes_multiple = function(ids, markers) {


    #markers = c(3:5, 15, 59, 60 , 61 , 120:130)
    r = marker_info$region_name[markers]

    i = 1

    #ids = 1:10
    nind = length(ids)
    nmark = length(markers)


    m = matrix(nrow = nmark, ncol = nind)
    m

    names_r = names(SIM$regions)

    x2 = markers

    for(i in 1:length(names_r)) {

        region = names_r[[i]]

        index1 = which(r == region)


        # Index of markers to retrieve from gt1,gt2
        markers1 = x2[index1]

        x2 = x2 - SIM$regions[[region]]$N_markers

        if(length(index1) == 0) next()

        cat("Retrieving genotypes  region ", region, " : MRK = " , markers1, " x ID = ", ids,"\n")

        m[ index1 , ] = retrieveGenotypes_selection(SIM$regions[[region]], markers1, ids )

        #gt1 = SIM$regions[[region]]$gt1[ markers1 , ids]
        #gt2 = SIM$regions[[region]]$gt2[ markers1 , ids]
        #m[ index1 , ] = as.matrix(gt1) # + as.matrix(gt2)
    }

    colnames(m) = ids
    t(m)
}

dim( retrieveGenotypes_multiple(1:15,62+1:20) )

dim( retrieveGenotypes(1:15,markers=1:10) )


#### k ####


library(sim1000G)
pkg.opts$debug_flag = 1
startMultipleRegionSimulation( list(vcf1, vcf2), region_names = c("a", "b"), totalNumberOfIndividuals = 3000 )
ids <- generateUnrelatedIndividuals(400)


str( as.list ( SIM ))
str( as.list ( SIM$regions[[1]] ), max.level = 1)


## Two ways to retrieve all the genotypes of individuals

g = retrieveGenotypes(c(ids[1],ids[3]), combine.regions = FALSE)
str(g)

g1 = retrieveGenotypes(  c(1:20) )

g2 = retrieveGenotypes(  c(1:20), 1:30)


dim(g1)
dim(g2)

g1
g1[,1:10] - g2[,1:10]

