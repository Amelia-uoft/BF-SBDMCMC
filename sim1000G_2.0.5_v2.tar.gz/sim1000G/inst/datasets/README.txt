
This directory will be used to save genetic maps and downloaded vcf files.

