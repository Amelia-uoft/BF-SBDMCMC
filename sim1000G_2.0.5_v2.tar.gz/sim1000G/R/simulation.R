
# pkg.env <- new.env()

###set = function(x) { pkg.env$x = x }
###get = function() { pkg.env$x }



#' Holds all data necessary for an ongoing simulation.
#' @export
SIM = new.env()



#' Holds general package options:
#' recombinatio: Recombination model in use: "chisq" or "poisson"
#' debug_flag: If set to 1, print additional debug information
#' 
#' @export
pkg.opts = new.env()
pkg.opts$recombination = 1
pkg.opts$debug_flag = 0


#' Set recombination model to either poisson (no interference) or chi-square.
#'
#'
#' @param model Either "poisson" or "chisq"
#'
#' @examples
#'
#'
#' generateUniformGeneticMap()
#'
#' do_plots = 0
#'
#' setRecombinationModel("chisq")
#' if(do_plots == 1)
#'  hist(generateRecombinationDistances(100000),n=200)
#'
#' setRecombinationModel("poisson")
#' if(do_plots == 1)
#'  hist(generateRecombinationDistances(100000),n=200)
#'
#' @export
setRecombinationModel = function(model) {

    if(model == "poisson") { pkg.opts$recombination = 0 }
    else
        if(model == "chisq") { pkg.opts$recombination = 1 }
        else
        { stop("model should be poisson or chisq")}


}






#' Starts and initializes the data structures required for a simulation. A VCF file
#' should be read beforehand with the function readVCF.
#'
#' @param vcf Input vcf object of a region, which should be read using the readVCF function. Must contain phased data.
#' @param totalNumberOfIndividuals Maximum number of individuals to allocate memory for. Set it above the number of individuals you want to simulate.
#' @param subset A subset of individual IDs to use for simulation
#' @param SIM_object If creating a manual multiple region simulation this argument contains a previous SIM object. Otherwise do not specify.
#'
#' @examples
#' library("sim1000G")
#' library(gplots)
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100)
#'
#'
#' genetic_map_of_region = system.file(
#'    "examples",
#'    "chr4-geneticmap.txt",
#'    package = "sim1000G"
#' )
#'
#' readGeneticMapFromFile(genetic_map_of_region)
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' @export
startSimulation = function(vcf, totalNumberOfIndividuals = 2000,
                           subset = NA,
                           SIM_object = NA
                           ) {

        cat("[#####...] Creating SIM object\n");

        SIMdata = new.env()

        # Original haplotypes from 1000 genomes / other data


        if(class(subset) == "logical" ) {
            SIMdata$population_gt1 = vcf$gt1
            SIMdata$population_gt2 = vcf$gt2
            SIMdata$individual_ids = vcf$individual_ids

        } else {

            s = which(vcf$individual_ids %in% subset)

            SIMdata$population_gt1 = vcf$gt1[,s]
            SIMdata$population_gt2 = vcf$gt2[,s]
            SIMdata$individual_ids = vcf$individual_ids[s]

            cat("Using", ncol(SIMdata$population_gt1), " individuals in simulation\n")

        }




        # Generate haplodata object

        haplomatrix = t( cbind(SIMdata$population_gt1, SIMdata$population_gt2) )

        #dim(haplomatrix)

        meanv = apply(haplomatrix,2,mean)
        #print( range(meanv) )

        non_polymorphic = which( meanv == 0 | meanv == 1 )
        polymorphic = which( meanv > 0  & meanv < 1 )

        if(length(non_polymorphic) >  0 )  {
            cat("Warning: Some variants are not polymorphic (ids =" ,
                non_polymorphic , ")\n");
        }



        SIMdata$non_polymorphic = non_polymorphic
        SIMdata$polymorphic = polymorphic


        SIMdata$haplodata = haplodata( haplomatrix[,polymorphic]  )
        cat("[#####...] Haplodata object created\n");



        # Variant information

        SIMdata$varinfo = vcf$vcf[,1:8]
        SIMdata$bp = vcf$vcf[,2]

        vcf_chrom = sub("^chr","",vcf$vcf[1,1])


        if( ! ( vcf_chrom %in% ls(geneticMaps) ) ) {

            cat("Downloading genetic map for chromosome " , vcf_chrom ,"\n" )

            readGeneticMap(vcf_chrom)

            #stop("ERROR: Genetic map has not been read yet\n");
        } else {



             if( ! ( vcf_chrom %in% ls(geneticMaps)  ) ) {
                 cat("Genetic map for chromosome", vcf_chrom, " not found", "\n")

                 stop("Error: genetic map for chromosome has not been downloaded");

             }


             s = range(geneticMaps[[vcf_chrom]]$bp)

             if( sum ( SIMdata$bp > s[2] | SIMdata$bp < s[1] ) > 0 ) {
                 cat("SIMdata locations: ", range(SIMdata$bp), "\n")
                 cat("geneticMaps range: ", range(s), "\n")
                stop("Error: Genetic map does not match the region being simulated\n");
             }
        }

        SIMdata$chrom = vcf_chrom

        SIMdata$cm = approx( geneticMaps[[vcf_chrom]]$bp, geneticMaps[[vcf_chrom]]$cm, SIMdata$bp )$y

        SIMdata$N_markers = nrow(vcf$gt1)

        SIMdata$pool = NA
        SIMdata$npool = 0

        SIMdata$total_individuals = totalNumberOfIndividuals
        SIMdata$individuals_generated = 0

        SIMdata$gt1 = matrix(ncol = SIMdata$total_individuals, nrow = SIMdata$N_markers, -1)
        SIMdata$gt2 = matrix(ncol = SIMdata$total_individuals, nrow = SIMdata$N_markers, -1)

        SIMdata$gt1 = as.data.frame(SIMdata$gt1)
        SIMdata$gt2 = as.data.frame(SIMdata$gt2)


        #SIMdata$origin1 = matrix(ncol = SIMdata$total_individuals, nrow = SIMdata$N_markers, -1)
        #SIMdata$origin2 = matrix(ncol = SIMdata$total_individuals, nrow = SIMdata$N_markers, -1)
        SIMdata$origin1 = list()
        SIMdata$origin2 = list()



        SIMdata$npool = 0
        SIMdata$last_ancestral_index = 10

        SIMdata$multipleRegion = FALSE

        #SIM$data = SIMdata



        if(!is.environment(SIM_object)) {

            # cleanup previous variables

            sim_functions = c("addUnrelatedIndividual", "addUnrelatedIndividualWithHaplotype", "reset", "mate")
            rm( list = setdiff( ls(SIM) , sim_functions) , envir = SIM )
            SIM$multipleRegion = FALSE

            for(i in ls(SIMdata)) {
                if(pkg.opts$debug_flag) cat("--- copy to base SIM ", i, "\n")

                SIM[[i]] = SIMdata[[i]]
            }
        } else {
              for(i in ls(SIMdata)) {
                if(pkg.opts$debug_flag) cat("--- copy to SIM_object ", i, "\n")
                SIM_object[[i]] = SIMdata[[i]]
            }
        }
}







#' Initializes a multiple region simulation, where the regions are treated as independent. A list of VCF files
#' should be read beforehand with the function readVCF and passed as arguments.
#'
#' @param vcfs List of input vcf objects that have been read using the readVCF function. Must contain phased data.
#' @param totalNumberOfIndividuals Maximum number of individuals to allocate memory for. Set it above the number of individuals you want to simulate.
#' @param subset A subset of individual IDs to use for simulation
#' @param region_names If not null, the regions are identified with the names specified. Should be the same length as vcfs.
#'
#' @examples
#' library("sim1000G")
#' library(gplots)
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf2_file = file.path(examples_dir, "region-chr4-93-TMEM156.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100)
#' vcf2 = readVCF( vcf2_file, maxNumberOfVariants = 100)
#'
#' generateUniformGeneticMap()
#'
#' startMultipleRegionSimulation( list(vcf, vcf2) , totalNumberOfIndividuals = 200)
#'
#' @export
startMultipleRegionSimulation = function(vcfs, totalNumberOfIndividuals = 2000,
                           subset = NA,
                           region_names = NULL

) {

    cat("[#####...] Creating a multiple region simulation\n");


    if( class(vcfs) != "list" ) {
        stop("vcfs must be a list of vcf objects read with readVCF function.")
    }

    sim_functions = c("addUnrelatedIndividual", "addUnrelatedIndividualWithHaplotype", "reset", "mate")
    rm( list = setdiff( ls(SIM) , sim_functions) , envir = SIM )

    n = length(vcfs)


    SIM$multipleRegion = TRUE
    SIM$nregions = n

    SIM$regions = list()


    for(i in 1:length(vcfs)) {
        V = vcfs[[i]]

        chrom = V$vcf[1,1]
        bp = V$vcf[1,2]
        cat("[#####...] (**) Adding region ", chrom, min(bp),max(bp), "\n")

        SIM$regions[[i]] = new.env()


        startSimulation(
            vcfs[[i]],
            totalNumberOfIndividuals = totalNumberOfIndividuals,
            subset = subset,
            SIM_object = SIM$regions[[i]]
        )
    }

    if(!is.null(region_names) && length(region_names) != length(vcfs)) {
        stop("Length of region_names should be the same as the list of vcfs")
    }

    if(is.null(region_names))
        region_names = sprintf("region%d", 1:length(vcfs) )

    names(SIM$regions) = region_names

    SIM$marker_info = markerInfo()
}




#' Retrieve information about the markers used in he simulation. The returned data frame
#' contains the chromosome, base pair and minor allele frequency of the markers.
#'
#' @param region Which region to compute the IBD for (only in multiple region simulation). Should be a single vector from the list of region names.
#'
#' @examples
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' str(markerInfo())
#' @export
markerInfo = function(region = NA) {

    if(! is.na(region)) {

        S = SIM$regions[[region]]

        ids = 1:length(S$bp)

        maf = apply(S$population_gt1 + S$population_gt2, 1, mean) / 2
        maf[ maf > 0.5 ] = 1 - maf[ maf > 0.5 ]

        markers = data.frame(marker_id = ids,
                            chrom = S$chrom,
                            bp = S$bp,
                            maf = maf,
                            stringsAsFactors = F
                    )

        return( markers )
    }

    if(SIM$multipleRegion) {

        maxN = 0

        R = list()

        for(i in 1:length(SIM$regions)) {

            S = SIM$regions[[i]]
            name = names(SIM$regions)[i]

            ids = 1:length(S$bp)
            ids = ids+maxN

            maxN = max(ids)

            maf = apply(S$population_gt1+S$population_gt2,1,mean)/2
            maf[maf>0.5] = 1 - maf[maf>0.5]


            R[[i]] = data.frame(region_name = name,
                marker_id = ids,
                chrom = S$chrom,
                bp = S$bp,
                maf = maf,
                stringsAsFactors = F
            )

        }

        return( do.call(rbind, R) )
    }

    ids = 1:length(SIM$bp)

    maf = apply(SIM$population_gt1+SIM$population_gt2,1,mean)/2
    maf[maf>0.5] = 1 - maf[maf>0.5]

    markers = data.frame(marker_id = ids,
                         chrom = SIM$chrom,
                         bp = SIM$bp,
                         maf = maf,
                         stringsAsFactors = F
                )
    return( markers )
}


















refreshPool = function(SIM) {

    SIM$npool = 500
    SIM$pool = t( haplosim2(SIM$npool, SIM$haplodata, summary = F) )   #  $data

    s = sample(1: SIM$npool, SIM$npool)
    #SIM$pool = SIM$pool[s,]

}


checkPool = function(SIM) {

    if(SIM$npool < 2) {
        #t <- system.time( refreshPool(SIM) )
        #print(t)
        refreshPool(SIM)
    }

}


generateNewHaplotypes = function(SIM, n = -1) {

    checkPool(SIM)

    nvar = nrow(SIM$population_gt1)

    gt1 = rep(0, nvar)
    gt2 = rep(0, nvar)


    gt1[SIM$polymorphic] = SIM$pool[,SIM$npool]
    gt2[SIM$polymorphic] = SIM$pool[,SIM$npool-1]

    GT = cbind(gt1, gt2)

    SIM$npool = SIM$npool - 2

    SIM$last_ancestral_index = SIM$last_ancestral_index  + 1

    return(GT)

}


addUnrelatedIndividualToSIM = function(SIM = NA) {

    checkPool(SIM)

    nvar = nrow(SIM$population_gt1)

    gt1 = rep(0, nvar)
    gt2 = rep(0, nvar)


    gt1[SIM$polymorphic] = SIM$pool[,SIM$npool]
    gt2[SIM$polymorphic] = SIM$pool[,SIM$npool-1]

    #GT = cbind(gt1, gt2)

    SIM$npool = SIM$npool - 2

    SIM$last_ancestral_index = SIM$last_ancestral_index  + 1




    if(SIM$individuals_generated >= SIM$total_individuals) {

        stop("No more space for saving new individual genotypes. Please increase the parameter totalNumberOfIndividuals when calling the function startSimulation.")

    }


    SIM$individuals_generated = SIM$individuals_generated + 1
    j = SIM$individuals_generated

    # cat("N less than 0 is:", sum(newGenotypes[,1]<0)  , sum (newGenotypes[,2]<0)  , "id=", j,"\n")
    # cat("Adding individual ",j, " from pool\n");

    SIM$gt1[,j] = gt1
    SIM$gt2[,j] = gt2

    SIM$origin1[[ j ]] = rep(SIM$last_ancestral_index, nvar)
    SIM$origin2[[ j ]] = rep(-SIM$last_ancestral_index, nvar)

    return(j)
}





#' Adds an unrelated individual to the simulation
#'
#' @examples
#' library("sim1000G")
#' library(gplots)
#'
#' @export
addUnrelatedIndividual = function() {

    if(SIM$multipleRegion) {
        r = sapply(SIM$regions, function(S) { return( addUnrelatedIndividualToSIM(S) ) } )
        if(pkg.opts$debug_flag) cat("addUnrelatedIndividual multiple : return = ", r, "\n")
        return(r[1])
    }

    return( addUnrelatedIndividualToSIM(SIM) )
}



SIM$addUnrelatedIndividual = function() {
    return( addUnrelatedIndividual() )
}





SIM$addUnrelatedIndividualWithHaplotype = function(SIM, new_haplotype, ancestral_index) {

    #    e1 = environment()
    #    print(parent.env(e1))
    #    print(ls(  parent.env(e1)   ))

    newGenotypes = generateNewHaplotypes(SIM)

    if(length(new_haplotype) !=  length(newGenotypes[,1])) {

        stop("new_haplotype length is wrong");
    }



    if(SIM$individuals_generated >= SIM$total_individuals) {

        stop("No more space for saving new individual genotypes. You can increase the parameter maximumNumberOfIndividuals when calling function startSimulation.")

    }


    SIM$individuals_generated = SIM$individuals_generated + 1
    j = SIM$individuals_generated

    # cat("Adding individual ",j, " from pool\n");
    nvar = nrow(newGenotypes)

    SIM$gt1[,j] = newGenotypes[,1]
    SIM$gt2[,j] = newGenotypes[,2]

    SIM$origin1[[ j ]] = rep(SIM$last_ancestral_index, nvar)
    SIM$origin2[[ j ]] = rep(-SIM$last_ancestral_index, nvar)


    SIM$gt2[,j] = new_haplotype
    SIM$origin2[[j]] = rep( - ancestral_index , nvar )

    return(j)
}





addIndividualFromGenotypes = function(SIM, gt1, gt2) {

    if(SIM$individuals_generated >= SIM$total_individuals) {

        stop("No more space for saving new individual genotypes. You can increase the parameter maximumNumberOfIndividuals when calling function startSimulation.")

    }

    SIM$individuals_generated = SIM$individuals_generated + 1
    j = SIM$individuals_generated

    # cat("Adding individual ",j, " from specified genotypes\n");

    SIM$gt1[,j] = gt1
    SIM$gt2[,j] = gt2


    return(j)
}






mate_internal = function(SIM, i, j)
{
    recomb1 = generateSingleRecombinationVector(SIM$cm)
    recomb2 = generateSingleRecombinationVector(SIM$cm)

    # FATHER1 = SIM$gt1[,i]
    # FATHER2 = SIM$gt2[,i]
    # MOTHER1 = SIM$gt1[,i]
    # MOTHER2 = SIM$gt2[,i]

    gt1 =  recomb1 * SIM$gt1[,i]  +  (1-recomb1) * SIM$gt2[,i]
    gt2 =  recomb2 * SIM$gt1[,j]  +  (1-recomb2) * SIM$gt2[,j]


    #gt1 = SIM$gt1[i,]
    #gt1[recomb1==1] = SIM$gt2[i,][recomb1==1]

    #gt2 = SIM$gt1[j,]
    #gt2[recomb1==1] = SIM$gt2[j,][recomb1==1]

    #cat("Mate: ",i," " ,j,"\n");

    #p1 = paste(SIM$gt1[,i],collapse="")
    #p2 = paste(SIM$gt2[,i],collapse="")
    #p3 = paste(gt1,collapse="")

    #cat("R1:", paste(recomb1,collapse=""),"\n",sep="")
    #cat("R2:", paste(recomb2,collapse=""),"\n",sep="")

    #cat(p1,"\n",p2,"\n",p3,"\n",sep="")

    SWAP = runif(1) < 0.5
    if(SWAP) { t = gt1; gt1 = gt2; gt2 = t; }


    index = addIndividualFromGenotypes(SIM, gt1, gt2)


    #gt1 =  recomb1 * SIM$gt1[,i]  +  (1-recomb1) * SIM$gt2[,i]
    #gt2 =  recomb2 * SIM$gt1[,j]  +  (1-recomb2) * SIM$gt2[,j]

    if(!SWAP) {
        SIM$origin1[[ index ]] = recomb1 * SIM$origin1[[ i ]] + (1-recomb1) * SIM$origin2[[ i ]];
        SIM$origin2[[ index ]] = recomb2 * SIM$origin1[[ j ]] + (1-recomb2) * SIM$origin2[[ j ]];
    } else {
        SIM$origin2[[ index ]] = recomb1 * SIM$origin1[[ i ]] + (1-recomb1) * SIM$origin2[[ i ]];
        SIM$origin1[[ index ]] = recomb2 * SIM$origin1[[ j ]] + (1-recomb2) * SIM$origin2[[ j ]];
    }

    # last_gt <<- gt1 + gt2

    return (index)
}



#' Generates a new individual as a descendant of i and j
#'
#' @param i Index of father
#' @param j Index of mother
#'
#' @return ID of individual generated
#'
#' @examples
#' library("sim1000G")
#' library(gplots)
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100)
#'
#' genetic_map_of_region = system.file(
#'    "examples",
#'    "chr4-geneticmap.txt",
#'    package = "sim1000G"
#' )
#'
#' readGeneticMapFromFile(genetic_map_of_region)
#'
#' @export
mate = function(i, j) {
    if(SIM$multipleRegion) {
        r = sapply(SIM$regions, function(S) { return( mate_internal(S, i, j) ) } )
        if(pkg.opts$debug_flag)  cat("Mate multiple : return = ", r, "\n")
        return(r[1])
    }

    return ( mate_internal(SIM, i, j) )
}



SIM$mate = function(i, j) {


    # For now, we hope i,j are of different sex
    return ( mate(i,j) )
}



SIM$reset = function() {
    resetSimulation()
}



#' Removes all individuals that have been simulated and resets the simulator.
#'
#'
#' @return nothing
#'
#' @examples
#'
#' resetSimulation()
#'
#' @export
resetSimulation = function() {

    if(SIM$multipleRegion) {


        for(i in 1:length(SIM$regions)) {
            SIM$regions[[i]]$pool = NA
            SIM$regions[[i]]$npool = 0
            SIM$regions[[i]]$individuals_generated = 0
        }

        return();
    }

    SIM$pool = NA
    SIM$npool = 0
    SIM$individuals_generated = 0
}




#' Generates variant data for n unrelated individuals
#'
#'
#' @param N how many individuals to generate
#'
#' @return IDs of the generated individuals
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 , min_maf = 0.12)
#'
#' genetic_map_of_region =
#'    system.file("examples",
#'      "chr4-geneticmap.txt",
#'      package = "sim1000G")
#'
#' readGeneticMapFromFile(genetic_map_of_region)
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 1200)
#' ids = generateUnrelatedIndividuals(20)
#'
#' # See also the documentation on our github page
#'
#' @export
generateUnrelatedIndividuals = function(N=1) {

    id = c()
    for(i in 1:N) id[i] = addUnrelatedIndividual()

    return( id )
}




#' Simulates genotypes for 1 family with 1 offspring
#'
#'
#'
#' @param family_id What will be the family_id (for example: 100)
#'
#' @return family structure object
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'    min_maf = 0.12 ,max_maf = NA)
#'
#' genetic_map_of_region = system.file("examples",
#'    "chr4-geneticmap.txt",
#'    package = "sim1000G")
#' readGeneticMapFromFile(genetic_map_of_region)
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 1200)
#' fam1 = newNuclearFamily(1)
#' fam2 = newNuclearFamily(2)
#'
#' # See also the documentation on our github page
#'
#' @export
newNuclearFamily = function(family_id) {

    fam = data.frame(family_id = family_id  ,
                     id = c(1,2,3) ,
                     father = c(0,0,1) ,
                     mother = c(0,0,2) ,
                     sex = c(1,2,1),
                     generation = c(1,1,2)
    )


    j1 = addUnrelatedIndividual()
    j2 = addUnrelatedIndividual()
    j3 = mate(j1,j2)


    fam$gtindex = c(j1,j2,j3)

    fam
}




#' Simulates genotypes for 1 family with n offspring.
#'
#'
#'
#' @param family_id What will be the family_id (for example: 100)
#' @param noffspring Number of offsprings that this family will have
#'
#' @return family structure object
#'
#' @examples
#'
#' ped_line = newFamilyWithOffspring(10,3)
#'
#'
#' @export
newFamilyWithOffspring = function(family_id, noffspring = 2) {

    fam = data.frame(fid = family_id  ,
                     id = c(1:2) ,
                     father = c(0,0),
                     mother = c(0,0),
                     sex = c(1,2),
                     generation = c(1,1)
    )


    j1 = addUnrelatedIndividual()
    j2 = addUnrelatedIndividual()

    fam$gtindex = c(j1,j2)

    for(i in 1:noffspring) {
        j3 = mate(j1,j2)
        newFamLine = c(family_id, i+10, 1,2, sample(c(1,2), 1) ,2 , j3)
        fam = rbind(fam, newFamLine)
    }

    return (fam)
}




#' Generates genotype data for a family of 3 generations
#'
#'
#'
#' @param familyid What will be the family_id (for example: 100)
#' @param noffspring2 Number of offspring in generation 2
#' @param noffspring3 Number of offspring in generation 3 (vector of length noffspring2)
#'
#' @return family structure object
#'
#' @export
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped_line = newFamily3generations(12, 3, c(3,3,2) )
newFamily3generations = function(familyid,
                                 noffspring2 = 2,
                                 noffspring3 = c(1,1)
                                 ) {

    if(length(noffspring3) == noffspring2){

        fam = data.frame(fid = familyid  ,
                         id = c(1:2) ,
                         father = c(0,0),
                         mother = c(0,0),
                         sex = c(1,2),
                         generation = c(1,1)
        )


        j1 = addUnrelatedIndividual()
        j2 = addUnrelatedIndividual()

        fam$gtindex = c(j1,j2)

        id2 <- 2
        for(i in 1:noffspring2) {
            id2 <- id2 + 1
            ids <- id2 + 1
            j3 = mate(j1,j2)
            gender2 <- sample(c(1,2), 1)
            genders <- ifelse(gender2 == 1, 2, 1)
            newFamLine = c(familyid, id2, 1,2, gender2,2,  j3)
            fam = rbind(fam, newFamLine)

            if(length(noffspring3[i] > 0)){
                j4 <- addUnrelatedIndividual()
                newFamLine = c(familyid, ids, 0,0, genders ,2,  j4)
                fam = rbind(fam, newFamLine)

                id3 <- ids
                for(j in 1:noffspring3[i]){
                    id3 <- id3 + 1
                    j5 <- mate(j3, j4)
                    father_id <- ifelse(gender2 == 1, id2, ids)
                    mother_id <- ifelse(gender2 == 2, id2, ids)
                    newFamLine = c(familyid, id3, father_id, mother_id, sample(c(1, 2), 1) ,3,  j5)
                    fam = rbind(fam, newFamLine)


                }
                id2 <- id3
            }
        }

        return (fam)
    }  else  {
        print(noffspring2)
        print(noffspring3)
        stop("The vector for number of offspring in the third generation (possibly zeros) must be equal to the number of offspring in the second generation")
    }
}



computePairIBD12_internal = function(SIM, i, j, allMarkers = FALSE) {

    i = as.numeric(i)
    j = as.numeric(j)

    q1 = SIM$origin1[[i]]
    q2 = SIM$origin2[[i]]

    r1 = SIM$origin1[[j]]
    r2 = SIM$origin2[[j]]

    # table(q1,q2)

    IBD1H1 = q1 == r1 | q1 == r2
    IBD1H2 = q2 == r1 | q2 == r2

    if(allMarkers) {
        IBD12 = IBD1H1 | IBD1H2
        IBD2 =  (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1)
        return(list(IBD1 = IBD12-IBD2, IBD2 = 0 + IBD2))
    }

    IBD12 = mean(IBD1H1 | IBD1H2)
    IBD2 = mean(   (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1) )

    c(IBD1 = IBD12 - IBD2, IBD2 = IBD2)
}




#' Computes pairwise IBD1/2 for a specific pair of individuals
#'
#'
#' @param i Index of first individual
#' @param j Index of second individual
#' @param markers Indexes of markers, returns IBD information only for the selected markers. Vector with elements from 1 to n (see markerInfo function).
#' @param allMarkers If true returns IBD for each marker in the region, otherwise return the mean value of IBD1 and IBD2 over the region.
#' @param region Which region to compute the IBD for (only in multiple region simulation). Should be a single vector from the list of region names.
#'
#' @return True IBD1 and IBD2 as computed from shared haplotypes. Returns the mean value if markers or allMarkers is not specified.
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' v = computePairIBD12(1, 3)
#'
#' cat("IBD1 of pair = ", v[1], "\n");
#' cat("IBD2 of pair = ", v[2], "\n");
#'
#' v = computePairIBD12(1, 3, markers = 1:10)
#'
#'
#' @export
computePairIBD12 = function(i, j, markers = c(), region = NA, allMarkers = FALSE) {

    i = as.numeric(i)
    j = as.numeric(j)

    if(!is.na(region)) {
        return( computePairIBD12_internal(SIM$regions[[region]], i, j, allMarkers = allMarkers) )
    }

    if(SIM$multipleRegion) {

        q1 = lapply(SIM$regions, function(S) { S$origin1[[i]] } )
        q2 = lapply(SIM$regions, function(S) { S$origin2[[i]] } )

        r1 = lapply(SIM$regions, function(S) { S$origin1[[j]] } )
        r2 = lapply(SIM$regions, function(S) { S$origin2[[j]] } )

        if(length(markers) > 0) {
            q1 = do.call(c, q1)[markers]
            q2 = do.call(c, q2)[markers]

            r1 = do.call(c, r1)[markers]
            r2 = do.call(c, r2)[markers]
        } else {
            q1 = do.call(c, q1)
            q2 = do.call(c, q2)

            r1 = do.call(c, r1)
            r2 = do.call(c, r2)
        }
    }

    if(!SIM$multipleRegion) {
        if(length(markers) > 0) {

            q1 = SIM$origin1[[i]][markers]
            q2 = SIM$origin2[[i]][markers]

            r1 = SIM$origin1[[j]][markers]
            r2 = SIM$origin2[[j]][markers]

        } else {

            q1 = SIM$origin1[[i]]
            q2 = SIM$origin2[[i]]

            r1 = SIM$origin1[[j]]
            r2 = SIM$origin2[[j]]

        }
    }

    # table(q1,q2)

    IBD1H1 = q1 == r1 | q1 == r2
    IBD1H2 = q2 == r1 | q2 == r2

    if(allMarkers) {
        IBD12 = IBD1H1 | IBD1H2
        IBD2 =  (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1)
        return(list(IBD1 = IBD12 - IBD2, IBD2 = 0 + IBD2))
    }


    IBD12 = mean(IBD1H1 | IBD1H2)
    IBD2 = mean(   (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1) )

    c(IBD1 = IBD12 - IBD2, IBD2 = IBD2)
}



IBD_computation = function(q1, q2, r1, r2, IBDType = 1, allMarkers = FALSE) {

    IBD1H1 = q1 == r1 | q1 == r2
    IBD1H2 = q2 == r1 | q2 == r2

    if(allMarkers) {
        IBD12 = IBD1H1 | IBD1H2
        IBD2 =  (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1)

        if(IBDType == 1) {
            return(IBD12 - IBD2)
        } else {
            return(0 + IBD2)
        }

    }

    IBD12 = mean(IBD1H1 | IBD1H2)
    IBD2 = mean(   (q1 == r1 & q2 == r2 )  | (q1 == r2 & q2 == r1) )

    if(IBDType == 1) {
        IBD1 = IBD12 - IBD2
        return(IBD1)
    } else {
        return(IBD2)
    }
}




#' Computes pairwise IBD1 for a specific pair of individuals.
#' See function computePairIBD12 for description.
#'
#'
#'
#' @param i Index of first individual
#' @param j Index of second individual
#' @param markers Indexes of markers, returns IBD information only for the selected markers. Vector with elements from 1 to n (see markerInfo function).
#' @param allMarkers If true returns IBD for each marker in the region, otherwise return the mean value of IBD1 and IBD2 over the region.
#'
#' @return Mean IBD1 as computed from shared haplotypes
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' # For realistic data use the function downloadGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' v = computePairIBD1(1, 3)
#'
#' cat("IBD1 of pair = ", v, "\n");
#'
#' @export
computePairIBD1 = function(i, j, markers = c(), allMarkers = FALSE) {

    i = as.numeric(i)
    j = as.numeric(j)

    if(SIM$multipleRegion) {

        q1 = lapply(SIM$regions, function(S) { S$origin1[[i]] } )
        q2 = lapply(SIM$regions, function(S) { S$origin2[[i]] } )

        r1 = lapply(SIM$regions, function(S) { S$origin1[[j]] } )
        r2 = lapply(SIM$regions, function(S) { S$origin2[[j]] } )

        if(length(markers) == 0) {
            q1 = do.call(c, q1)
            q2 = do.call(c, q2)

            r1 = do.call(c, r1)
            r2 = do.call(c, r2)
        } else {
            q1 = do.call(c, q1)[markers]
            q2 = do.call(c, q2)[markers]

            r1 = do.call(c, r1)[markers]
            r2 = do.call(c, r2)[markers]
        }

    }

    if(!SIM$multipleRegion) {
        if(length(markers) > 0) {

            q1 = SIM$origin1[[i]][markers]
            q2 = SIM$origin2[[i]][markers]

            r1 = SIM$origin1[[j]][markers]
            r2 = SIM$origin2[[j]][markers]

        } else {

            q1 = SIM$origin1[[i]]
            q2 = SIM$origin2[[i]]

            r1 = SIM$origin1[[j]]
            r2 = SIM$origin2[[j]]

        }
    }

    IBD_computation(q1, q2, r1, r2, 1, allMarkers)
}







#' Computes pairwise IBD2 for a specific pair of individuals
#'
#'
#'
#' @param i Index of first individual
#' @param j Index of second individual
#' @param markers Indexes of markers, returns IBD information only for the selected markers. Vector with elements from 1 to n (see markerInfo function).
#' @param allMarkers If true returns IBD for each marker in the region, otherwise return the mean value of IBD1 and IBD2 over the region.
#'
#' @return Mean IBD2 as computed from shared haplotypes
#'
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' # For demonstration, this function uses a uniform map
#' # Usually you would use the function downloadGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' v = computePairIBD2(1, 3)
#'
#' cat("IBD2 of pair = ", v, "\n");
#'
#' @export
computePairIBD2 = function(i, j, markers = c(), allMarkers = FALSE) {

    i = as.numeric(i)
    j = as.numeric(j)

    if(SIM$multipleRegion) {

        q1 = lapply(SIM$regions, function(S) { S$origin1[[i]] } )
        q2 = lapply(SIM$regions, function(S) { S$origin2[[i]] } )

        r1 = lapply(SIM$regions, function(S) { S$origin1[[j]] } )
        r2 = lapply(SIM$regions, function(S) { S$origin2[[j]] } )

        if(length(markers) == 0) {
            q1 = do.call(c, q1)
            q2 = do.call(c, q2)

            r1 = do.call(c, r1)
            r2 = do.call(c, r2)
        } else {
            q1 = do.call(c, q1)[markers]
            q2 = do.call(c, q2)[markers]

            r1 = do.call(c, r1)[markers]
            r2 = do.call(c, r2)[markers]
        }

    }

    if(!SIM$multipleRegion) {
        if(length(markers) > 0) {

            q1 = SIM$origin1[[i]][markers]
            q2 = SIM$origin2[[i]][markers]

            r1 = SIM$origin1[[j]][markers]
            r2 = SIM$origin2[[j]][markers]

        } else {

            q1 = SIM$origin1[[i]]
            q2 = SIM$origin2[[i]]

            r1 = SIM$origin1[[j]]
            r2 = SIM$origin2[[j]]

        }
    }


    IBD_computation(q1, q2, r1, r2, 2, allMarkers)
}








#' Computes both IBD1 and IBD2 matrices for a selected number of individuals. 
#' Given two arguments ids1, ids2, the function computes the pairwise IBD for each individual from ids1 versus each one from ids2.
#' Row i and column j contains the IBD information for pair ids1[i] & ids2[j].
#'
#' @param ids1 List of individual ids for the rows of the matrix.
#' @param ids2 List of individual ids for the columns of the matrix. Can be the same as ids1
#' @param markers Indexes of markers, returns IBD information only for the selected markers. Vector with elements from 1 to n (see markerInfo function).
#'
#' @return A list of two matrices, IBD1 and IBD2. Each matrix has length(ids1) rows and length(ids2) columns.
#'
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 300 ,
#'                min_maf = 0.03 ,max_maf = NA)
#'
#' # For demonstration, this function uses a uniform map
#' # Usually you would use the function downloadGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' v = computeIBDMatrix(ped1$gtindex, ped1$gtindex)
#' print(v)
#'
#' @export
computeIBDMatrix = function(ids1, ids2, markers = c()) {

    if(SIM$multipleRegion) {
        q1 = collectOrigin1(ids1)
        q2 = collectOrigin2(ids1)

        r1 = collectOrigin1(ids2)
        r2 = collectOrigin2(ids2)
    }

    if(!SIM$multipleRegion) {

        q1 = SIM$origin1[ids1]
        q1 = do.call(rbind, q1)

        q2 = SIM$origin2[ids1]
        q2 = do.call(rbind, q2)


        r1 = SIM$origin1[ids2]
        r1 = do.call(rbind, r1)

        r2 = SIM$origin2[ids2]
        r2 = do.call(rbind, r2)
    }


    if(length(markers) > 0) {
        q1 = q1[,markers]
        q2 = q2[,markers]

        r1 = r1[,markers]
        r2 = r2[,markers]
    }



    if(pkg.opts$debug_flag) {

        cat("Hello! dimensions of q1 is ", dim(q1),"\n")
        cat("Hello! dimensions of q2 is ", dim(q2),"\n")
        cat("Hello! dimensions of r1 is ", dim(r1),"\n")
        cat("Hello! dimensions of r2 is ", dim(r2),"\n")

    }


    # Result matrices

    IBD1matrix = matrix(nrow = length(ids1), ncol = length(ids2), NA )
    IBD2matrix = matrix(nrow = length(ids1), ncol = length(ids2), NA )


    # Compute each row of the matrix separately

    for(i in 1:length(ids1)) {

        x = q1[i,]
        y = q2[i,]

        nind = nrow(r1)

        Q1 = matrix(x, byrow = T, nrow = nrow(r1), ncol = ncol(r1))

        Q2 = matrix(y, byrow = T, nrow = nrow(r1), ncol = ncol(r1))

        IBD1H1 = Q1 == r1 | Q1 == r2
        IBD1H2 = Q2 == r1 | Q2 == r2

        IBD12 = IBD1H1 | IBD1H2
        IBD2 =  (Q1 == r1 & Q2 == r2 )  | (Q1 == r2 & Q2 == r1)

        meanIBD12 = rowMeans(IBD12)
        meanIBD2 = rowMeans(IBD2)

        IBD1matrix[i,] = meanIBD12 - meanIBD2
        IBD2matrix[i,] = meanIBD2

    }

    list(IBD1 = IBD1matrix, IBD2 = IBD2matrix)
}



collectOrigin1 = function(ids1) {
    x = lapply(SIM$regions, function(S) { q = S$origin1[ids1]; do.call(rbind,q) } )
    do.call(cbind, x)
}

collectOrigin2 = function(ids1) {
    x = lapply(SIM$regions, function(S) { q = S$origin2[ids1]; do.call(rbind,q) } )
    do.call(cbind, x)
}







#' Utility function that prints a matrix. Useful for IBD12 matrices.
#'
#'
#' @param m Matrix to be printed
#'
#' @examples
#'
#' printMatrix (  matrix(runif(16), nrow=4) )
#' @export
#'
printMatrix = function(m) {
    cat("      " , " " , sprintf("[%4d] ", 1:nrow(m) )  , "\n")

    for(i in 1:nrow(m)) {

        cat(sprintf("[%4d]",i) , " " , sprintf(" %.3f ", m[i,]) , "\n")
    }

}





retrieveGenotypes_internal = function(SIM, ids) {
    ids = as.numeric(ids)

    if(pkg.opts$debug_flag)
        cat("Retrieve genotypes from single region:", ids, "\n")

    if(length(ids) == 1) {
        return(SIM$gt1[,ids] + SIM$gt2[,ids])
    }

    m = t(SIM$gt1[,ids] + SIM$gt2[,ids])

    rownames(m) = ids

    m
}




retrieveGenotypes_selection = function(SIM, markers, ids) {
    ids = as.numeric(ids)

    if(length(ids) == 1) {
        gt1 = as.matrix(SIM$gt1[markers, ids])
        gt2 = as.matrix(SIM$gt2[markers, ids])

        return(gt1 + gt2)
    }

    gt1 = as.matrix(SIM$gt1[markers, ids])
    gt2 = as.matrix(SIM$gt2[markers, ids])

    m = t(gt1 + gt2)

    rownames(m) = ids

    m
}




retrieveGenotypes_multiple = function(ids, markers) {

    gt1_all = lapply(SIM$regions, function(x) x$gt1[,ids])
    gt2_all = lapply(SIM$regions, function(x) x$gt2[,ids])

    gt1_all = do.call(rbind, gt1_all)
    gt2_all = do.call(rbind, gt2_all)

    m = t( gt1_all[markers,] + gt2_all[markers,] )

    rownames(m) = ids
    return(m)

}




#' Retrieve a matrix of simulated genotypes for a specific set of individual IDs
#'
#'
#' @param ids Individuals to retrieve (vector of IDs).
#' @param markers Which markers to retrieve (see markerInfo). Vector of IDs or NA to retrieve all. Default: NA
#' @param region Which region to return (only in multiple region simulation). Should be a single element from the list of region names.
#' @param combine.regions If FALSE, returns a list containing markers for every region, otherwise returns a single matrix. Default: True.
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' # For realistic data use the function downloadGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' retrieveGenotypes(ped1$gtindex)
#'
#' @export
#'
retrieveGenotypes = function(ids, markers = NA, region = NA, combine.regions = TRUE) {

    ids = as.numeric(ids)

    if(!missing(markers) && !missing(region)) {
        stop("Cannot specify both markers and a region")
    }

    if(!missing(region)) {
        return( retrieveGenotypes_internal(SIM$regions[[region]], ids) )
    }

    if(!missing(markers)) {

        if(SIM$multipleRegion) {
            return ( retrieveGenotypes_multiple(ids, markers) )
        } else {

            if(length(ids) == 1) {
                return(SIM$gt1[markers, ids] + SIM$gt2[markers, ids])
            }

            m = t(SIM$gt1[markers, ids] + SIM$gt2[markers, ids])

            rownames(m) = ids

            return(m)
        }

    }


    if(SIM$multipleRegion) {
        r = lapply(SIM$regions, function(S) { return( retrieveGenotypes_internal(S, ids) ) } )

        if(length(ids) == 1) {
            return( do.call(c, r) )
        }

        if(combine.regions) {
            r = do.call(cbind, r)
        }

        return(r)
    }

    # cat("Retrieve genotypes from single region (2):", ids, "\n")

    if(length(ids) == 1) {
        return(SIM$gt1[,ids] + SIM$gt2[,ids])
    }

    m = t(SIM$gt1[,ids] + SIM$gt2[,ids])

    rownames(m) = ids

    m
}




saved_SIM = new.env()


#' Save the data for a simulation for later use. When simulating multiple populations it
#' allows saving and restoring of simulation data for each population.
#'
#' @param id Name the simulation will be saved as.
#'
#' @examples
#'
#'
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#'
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#'
#' # For realistic data use the functions downloadGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' saveSimulation("sim1")
#'
#' @export
#'
saveSimulation = function(id) {
    saved_SIM[[id]] = as.list(SIM)
    SIM = new.env()
}







#' Load some previously saved simulation data by function saveSimulation
#'
#' @param id Name the simulation to load which was previously saved by saveSimulation
#'
#' @examples
#'
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'            min_maf = 0.12 ,max_maf = NA)
#'
#' # For a realistic genetic map
#' # use the function readGeneticMap
#' generateUniformGeneticMap()
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#'
#' ped1 = newNuclearFamily(1)
#'
#' saveSimulation("sim1")
#'
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.02 ,max_maf = 0.5)
#'
#' startSimulation(vcf, totalNumberOfIndividuals = 200)
#' saveSimulation("sim2")
#'
#' loadSimulation("sim1")
#'
#'
#'
#' @export
#'
loadSimulation = function(id) {

    print(names(saved_SIM))

    x = saved_SIM[[id]]

    for(i in names(x)) SIM[[i]] = x[[i]]

    cat(" N=" , length(SIM$individual_ids), " individuals in origin simulation pool.\n")

    SIM$npool = 0

}








