



#' Holds the genetic maps information that is used for simulations.
#' @export
geneticMaps <- new.env()

#' Holds the CDF information for the genetic maps
#' This lists of vectors contain the density between two recombination events, as a cumulative density function.
##' @export
crossoverCDFvector = NA




#' Generate recombination distances using a no-interference model.
#'
#'
#' @param n Number of distances to generate
#'
#' @return recombination distances in centimorgan
#' @examples
#'
#' library("sim1000G")
#' mean ( generateRecombinationDistances_noInterference ( 200 ) )
#'
#' @export
generateRecombinationDistances_noInterference = function ( n ) {

    rexp(n, 0.01)

}








#' Genetates a recombination vector arising from one meiotic event.
#' The origin of segments is coded as (0 - haplotype1 ,  1 - haplotype2 )
#'
#' @param cm The length of the region that we want to generate recombination distances.
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = file.path(examples_dir, "region.vcf.gz")
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' # For realistic data use the function downloadGeneticMap
#' generateUniformGeneticMap()
#' generateSingleRecombinationVector( 1:100 )
#'
#' @export
generateSingleRecombinationVector = function(cm) {

    if(pkg.opts$debug_flag) cat("generateSingleRecombinationVector l=",diff(range(cm)),"\n")

    n = length(cm)
    maxCM = max(cm)

    pos = generateRecombinationDistances(14)

    while(sum(pos) < maxCM) pos = c(pos, generateRecombinationDistances(10) )
    if(sum(pos) < maxCM) { stop("Not enough recombination events"); }

    pos = cumsum(pos)

    recombVector = rep(TRUE, n)

    p = findInterval(pos,cm)


    for(i in 1:length(pos)) {

        if(p[i] < n) recombVector[ p[i]:n ] =  !recombVector[ p[i]:n ]

        #s = cm > pos[i]
        #if(runif(1) < 0.5)
        #recombVector [ s ]  = recombVector [ s ]  + 1

    }

    #  recombVector = recombVector %% 2
    if(runif(1,0,1) < 0.5) recombVector = ! recombVector

    recombVector+0

}







#' Generates a recombination vector arising from one meiotic event.
#' The origin of segments is coded as (0 - haplotype1 ,  1 - haplotype2 )
#'
#' @param chromosomeLength The length of the region in cm.
#'
#' @examples
#'
#' library("sim1000G")
#'
#' # generate a recombination events for chromosome 4
#' readGeneticMap(4)
#' generateChromosomeRecombinationPositions(500)
#'
#' @export
generateChromosomeRecombinationPositions = function(chromosomeLength = 500) {

    pos = generateRecombinationDistances(10)

    while(sum(pos) < chromosomeLength) pos = c(pos, generateRecombinationDistances(10) )

    pos = cumsum(pos)

    pos = pos[pos <= chromosomeLength]
    pos
}










#' Downloads a genetic map for a particular chromosome under GRCh37 coordinates for use with sim1000G.
#'
#' @param chromosome Chromosome number to download recombination distances from.
#' @param dir Directory to save the genetic map to (default: temporary directory)
#'
#'
#' @examples
#'
#'
#'
#' downloadGeneticMap(22, dir=tempdir() )
#'
#'
#' @export
downloadGeneticMap = function(chromosome, dir = NA) {


        fname = sprintf("genetic_map_GRCh37_chr%s.txt.gz" , chromosome )

        url = sprintf(
            "https://github.com/adimitromanolakis/geneticMap-GRCh37/raw/master/genetic_map_GRCh37_chr%s.txt.gz",
            chromosome
        )


        if(is.na(dir)) {
            #dest_dir = system.file("datasets", package = "sim1000G")
            #if(dest_dir == "") dest_dir = tempdir()
            dest_dir = tempdir()

            if(!dir.exists(dest_dir))  dest_dir = tempdir()
        } else {
            dest_dir = dir
        }


        #dest_dir = "./"
        dest_path = file.path(dest_dir, fname)


        if(file.exists(dest_path)) {
            cat(" -> Using genetic map found on ", dest_path, "\n");
            return(dest_path)

        }

        cat(" -> Downloading genetic map from:",url,"\n")
        cat(" -> Saving genetic map to: " , dest_path,"\n")

        download.file(url  ,  destfile = dest_path, quiet=TRUE)
        return(dest_path)

}





#' Reads a genetic map downloaded from the function downloadGeneticMap or reads a genetic map from a specified file. If the argument filename is used
#' then the genetic map is read from the corresponding file. Otherwise, if a chromosome is specified, the genetic map is downloaded for human chromosome
#' using grch37 coordinates.
#'
#' The map must contains a complete chromosome or enough markers to cover the area that
#' will be simulated.
#'
#'
#' @param chromosome Chromosome number to download a genetic map for , or
#' @param filename A filename of an existing genetic map to read from (default NA).
#' @param dir Directory the map file will be saved (only if chromosome is specified).
#'
#'
#'
#' @examples
#'
#'
#'
#'
#' readGeneticMap(chromosome = 22)
#'
#'
#'
#' @export
readGeneticMap = function(chromosome, filename=NA, dir=NA) {


    if( ! is.na(filename) ) { return ( readGeneticMapFromFile(filename) ) }
    #if(is.na(dir)) dir = system.file("extdata", package = "sim1000G")

    fname = downloadGeneticMap( chromosome, dir = dir)

    readGeneticMapFromFile(fname)

}




#' Reads a genetic map to be used for simulations. The genetic map should be
#' of a single chromosome and covering the extent of the region to be simulated.
#' Whole chromosome genetic maps can also be used.
#'
#' The file must be contain the following columns in the same order: chromosome, base pair, rate(not used), centimorgan
#'
#'
#' @param filelocation Filename containing the genetic map
#' @examples
#'
#' \dontrun{
#'
#' fname = downloadGeneticMap(10)
#'
#' cat("genetic map downloaded at :", fname, "\n")
#' readGeneticMapFromFile(fname)
#'
#' }
#' @export
readGeneticMapFromFile = function(filelocation) {

    if(! file.exists(filelocation) ) {
        stop(sprintf("Genetic map file %s not found",filelocation))
    }

    a = read.table(filelocation, as.is=TRUE, header=TRUE)
    colnames(a) = c("chr","bp","rate.cm","cm")
    a = a[ order(a$cm),]
    a

    map = new.env()

    map$chr = sub("^chr","", a$chr)

    chrom = as.character(map$chr[1])

    cat(" -> Reading genetic map for chromosome ", chrom, "\n")

    map$bp = a$bp
    map$cm = a$cm

    cat(" -> Genetic map has" , length(map$bp), "entries\n");
    geneticMaps[[chrom]] = map

    if(! ( "vector" %in% ls(crossoverCDF)) ) {
        makeCDF()
    }
}



#' Generates a uniform genetic map.
#'
#'
#' Generates a uniform genetic map by approximating 1 cm / Mbp. Only used for examples.
#'
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = sprintf("%s/region.vcf.gz", examples_dir)
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100 ,
#'                min_maf = 0.12 ,max_maf = NA)
#'
#' # For realistic data use the function readGeneticMap
#' generateUniformGeneticMap()
#'
#' pdf(file=tempfile())
#' plotRegionalGeneticMap(2, seq(1e6,100e6,by=1e6/2))
#' dev.off()
#'
#' @export
generateUniformGeneticMap = function() {

    n = 10000
    bp = seq(0,300e6, by=50000)
    cm = bp / 1e6


    for(chrom in 1:22) {
        geneticMaps[[ as.character(chrom) ]] = data.frame(
            chr = rep(chrom, length(bp)),
            bp = bp,
            cm = cm
        )
    }


    makeCDF();
    
    return(0)
}



# Generates a fake genetic map that spans the whole genome.
generateFakeWholeGenomeGeneticMap = function(chrom, vcf) {

    n = 10000
    bp = vcf$vcf[,2]
    cm = seq(0,4000, l=length(bp))

    geneticMap$chr = rep(4, length(bp))
    geneticMap$bp = bp
    geneticMap$cm = cm

    makeCDF();
    0;

}







#' Converts centimorgan position to base-pair. Return a list of centimorgan positions that correspond
#' to the bp vector (in basepairs).
#' 
#' @param chrom Chromosome number
#' @param bp vector of base-pair positions
#'
#' @examples
#'
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = sprintf("%s/region.vcf.gz", examples_dir)
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100,
#'   min_maf = 0.12)
#'
#' # For realistic data use the function downloadGeneticMap
#' generateUniformGeneticMap()
#' getCMfromBP(1, seq(1e6,100e6,by=1e6))
#'
#'
#' @export
getCMfromBP = function(chrom, bp) {
    chrom = as.character(chrom)
    approx( geneticMaps[[chrom]]$bp, geneticMaps[[chrom]]$cm, bp )$y
}



#' Generates a plot of the genetic map for a specified region.
#'
#' The plot shows the centimorgan vs base-pair positions.
#' The position of markers that have been read is also depicted as vertical lines
#'
#' @param chrom Chromosome number
#' @param bp Vector of base-pair positions to generate a plot for
#' library("sim1000G")
#'
#' examples_dir = system.file("examples", package = "sim1000G")
#' vcf_file = sprintf("%s/region.vcf.gz", examples_dir)
#' vcf = readVCF( vcf_file, maxNumberOfVariants = 100,
#'   min_maf = 0.12)
#'
#' # For realistic data use the function readGeneticMap
#' generateUniformGeneticMap()
#'
#' pdf(file=tempfile())
#' plotRegionalGeneticMap(2, seq(1e6,100e6,by=1e6/2))
#' dev.off()
#'
#'
#' @export
plotRegionalGeneticMap = function(chrom = 1, bp = seq(0,100e6,by=50000) ) {
    
    chrom = as.character(chrom)

    cm = approx(geneticMaps[[chrom]]$bp, geneticMaps[[chrom]]$cm, bp)$y


    len = diff(range(cm))
    print(len)

    plot(bp/1e6,cm, t="l",cex=0.2, xlab="MBp", ylab = "Centimorgan")
    segments( bp/1e6,cm,  bp/1e6,cm - len/10, lwd=0.3,col="blue")

}







fgammamod = function(x,L, n) {

    (x**(n-1))*exp(-L*x)    *  (L**n)/gamma(n)
}


fstar = function(x,q,l) {


    sum1 = 0
    for(k in 1:5)
        sum1 = sum1 + fgammamod(x, 2*q*(l+1) , k*(l+1))/ (2**k)

    sum1

}





#plot(function(x) fstar(x,1,4.5),xlim=c(0,3), xlab="Morgans", ylab="Density")
#title("Crossover distance")
#abline(h=1,col="gray")


#' Cross over CDF vector
#'
#'
#' @export
crossoverCDF = new.env()

makeCDF = function() {

    dens = sapply(seq(0,4,by=0.001), function(x) fstar(x,1/1.108,1) )  # originally was 3.2

    cdf = cumsum(dens)
    cdf = cdf/max(cdf)

    cdf[1:10]
    crossoverCDF$vector = cdf
    crossoverCDFvector

}

# To test:
#makeCDF(); mean(generateRecombinationDistances(1000000)); hist(generateRecombinationDistances(100e3),n=1000)






#' Generate inter-recombination distances using a chi-square model. Note this are the distances between two succesive recombination events and not
#' the absolute positions of the events. To generate the locations of the recombination events see the example below.
#'
#'
#' @param n Number of distances to generate
#'
#' @return vector of distances between two recombination events.
#'
#' @examples
#'
#' library("sim1000G")
#'
#' distances = generateRecombinationDistances(20)
#'
#'
#' positions_of_recombination = cumsum(distances)
#'
#' if(0) hist(generateRecombinationDistances(20000),n=100)
#'
#' @export
generateRecombinationDistances = function ( n ) {


    if(pkg.opts$recombination == 0) { return(generateRecombinationDistances_noInterference(n))}


    t = findInterval( runif(n), crossoverCDF$vector )
    t = t * 4 / length(crossoverCDF$vector)
    100 * t
}




