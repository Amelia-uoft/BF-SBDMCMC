#### Test 1: Retrieve selected markers ####

mustBeIdentical = function( a , b) {
    stopifnot( max( abs( a-b ) ) == 0 )
}


rm(retrieveGenotypes, retrieveGenotypes_internal, retrieveGenotypes_multiple )


x1 = retrieveGenotypes(1:10)
x2 = retrieveGenotypes(1:10, 1:20)

mustBeIdentical( x1[,1:20] , x2 )





x1 = retrieveGenotypes(1:10)
x2 = retrieveGenotypes(1:10, 100+1:20)

mustBeIdentical( x1[,100 + 1:20] , x2 )





x1 = retrieveGenotypes(30)
x2 = retrieveGenotypes(40)
x3 = retrieveGenotypes(c(30,40))

mustBeIdentical(  rbind(x1,x2) ,  x3 )


#### Test 2: IBD12 computations ####




#startSimulation(vcf2, totalNumberOfIndividuals = 4444)


readGeneticMap(4, dir = "/tmp")
readGeneticMap(6, dir = "/tmp")


startMultipleRegionSimulation( list(vcf1, vcf2), region_names = c("a", "b"), totalNumberOfIndividuals = 5000 )

marker_info = markerInfo()


#ids <- generateUnrelatedIndividuals(400)




x = SIM$regions[[1]]$cm
x = seq(0,2000,l=length(x) )
SIM$regions[[1]]$cm = x


x = SIM$regions[[2]]$cm
x = seq(0,2000,l=length(x) )
SIM$regions[[2]]$cm = x


resetSimulation()
generateUnrelatedIndividuals(10)

child1 = mate(1,2)
child2 = mate(1,2)






x1 = computePairIBD12(child1, child2, allMarkers = T)
x2 = computePairIBD12(child1, child2, markers = 37:99, allMarkers = T)

mustBeIdentical( x1$IBD1[37:99] , x2$IBD1 )
mustBeIdentical( x1$IBD2[37:99] , x2$IBD2 )



x1 = computePairIBD12(child1, child2, allMarkers = T)
x2 = computePairIBD1(child1, child2,  allMarkers = T)
x3 = computePairIBD2(child1, child2,  allMarkers = T)

mustBeIdentical( x1$IBD1 , x2 )
mustBeIdentical( x1$IBD2 , x3 )






x1 = computePairIBD12(child1, child2, markers = 1:10, allMarkers = T)
x2 = computePairIBD1(child1, child2, markers = 1:10, allMarkers = T)
x3 = computePairIBD2(child1, child2, markers = 1:10, allMarkers = T)

mustBeIdentical( x1$IBD1 , x2 )
mustBeIdentical( x1$IBD2 , x3 )





x1 = computePairIBD12(child1, child2, allMarkers = F)
x2 = computePairIBD1(child1, child2,  allMarkers = F)
x3 = computePairIBD2(child1, child2,  allMarkers = F)

x1
mustBeIdentical( x1[1] , x2 )
mustBeIdentical( x1[2] , x3 )







