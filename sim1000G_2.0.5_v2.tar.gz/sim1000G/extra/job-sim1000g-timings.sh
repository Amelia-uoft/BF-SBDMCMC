#!/bin/bash
cd "/home/briollaislab/adimitro/tmp"
PATH=/usr/bin:/software/R-3.0.0/bin:$PATH
Rscript timings.R
